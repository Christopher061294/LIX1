//
//  declaration_of_variables.cpp
//
#include <iostream>
using namespace std;

int main()
{
    int x,y; // declaring variables
    int result; // still declaring variables
    /* assignment */
    x = 1;
    y = 2;
    result = x + y;
    cout << result << endl;// print the result
    
    return 0;
}
