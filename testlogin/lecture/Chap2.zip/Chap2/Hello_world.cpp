//
//  Hello_world.cpp
//

#include <iostream> // Including the information in the C++ Standard Library

using namespace std; // Will be explained later

int main() // entry point of the program
{
    
    /* You can change Hello World! to whatever you like as long as you don't change the "your words" format*/
    cout << "Hello World!" << endl;

    return 0; // a nice and normal ending

}
