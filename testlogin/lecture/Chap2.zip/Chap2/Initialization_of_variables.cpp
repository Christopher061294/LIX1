//
//  Initialization_of_variables.cpp
//  
#include <iostream>
using namespace std;

int main()
{
    int x = 1; // initial value of a is 1
    int y = 2; // initial value of b is 2
    int result = 0; //initial value of result is 0
    
    result = x + y;
    cout << result << endl; // print the reuslt
    
    return 0;
}

int x = 1;
int y = 0;
