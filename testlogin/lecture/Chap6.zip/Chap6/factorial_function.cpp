//
//  factorial_function.cpp
//
#include<iostream>
using namespace std;

int recursive_factorial(int x)
{
    if(x < 0)
        return -1;  // error checking
    if(x > 1)
        return x * factorial(x - 1); // function itself (underlying principle)
    else
        return 1;  // base case
}
int main()
{
    int a = 10;
    cout << "Factorial of " << a << " = " << recursive_factorial(a);
    return 0;
}

