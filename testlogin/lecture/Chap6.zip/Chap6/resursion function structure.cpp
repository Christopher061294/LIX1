//
//  resursion function structure.cpp
//

function_type function_name ( parameter_list )
{
    if(error_case)
    {return -1;}    // error checking, the function will not continue if the parameter is not suitable.
    
    else if(base_case)
    {return base_case;} // return the base case and the recursion will stop.
    
    else
    {return function;} // neither error or base case is detected and the function will keep calling itself.
    
}
