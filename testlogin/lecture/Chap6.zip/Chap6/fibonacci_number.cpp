//
//  fibonacci_number.cpp
//  
#include<iostream>
using namespace std;

int fibonacci_number(int n)
{
    if(n < 0)
    {
        return -1;  // error checking
    }
    if((n==1)||(n==0))
    {
        return(n);  // base case
    }
    else
    {
        return(fibonacci_number(n-1)+fibonacci_number(n-2));
        // function itself
    }
}
int main()
{
    int n = 6;
    int i = 0;
    
    while(i<n) // we have 6 iterations in total
    {
        cout << fibonacci_number(i);
        i++;
    }
    return 0;
}
