//
//  swap with pass by reference.cpp
//

#include <iostream>
using namespace std;

void swap(int &a,int &b) // share the same memory location with actual parameter 
{
    int temp;
    temp=a;
    a=b;
    b=temp;
    
    return;
}
int main () {
    
    int x = 1;
    int y = 2;
    
    cout << x << endl; // output the original x
    cout << y << endl; // output the original y
    
    swap(x, y); // call the swap function with reference variable
    
    cout << x << endl; // output the x after called swap
    cout << y << endl; // output the y after called swap
    
    return 0;
}
