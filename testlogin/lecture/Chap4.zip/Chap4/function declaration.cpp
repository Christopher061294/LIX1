//
//  function declaration.cpp
//  

#include <iostream>
using namespace std;

int main() {

    int min (int, int);
    // return type, function name, parameter list
    // notice that parameter names are not important in function declaration, so we do not need to (int x, int x).
    
    return 0;
}
