//
//  calling function.cpp
//

#include <iostream>
using namespace std;

int min(int a, int b){
    
    if (a < b)
        return a;
    else
        return b;
}

int main()
{
    int x = 1;
    int y = 100;
    int answer;
    
    answer = min(x,y); // call with the function name and parameter list
    cout << "The smaller number is" << answer << endl;
    
    return 0;
}
