//
//  swap with passbyvalue.cpp
//  

#include <iostream>
using namespace std;

void swap(int a,int b) // void mean does not return a thing
{
    int temp; // allocate an int memory location
    temp=a; // save the value of a first
    a=b;    // assign the value of b to a
    b=temp; // assign the value of temp which is a to b
    
    return;
}
int main () {
    
    int x = 1;
    int y = 2;
    
    cout << x << endl; // output the original x
    cout << y << endl; // output the original y
    
    swap(x, y); // call the swap function
    
    cout << x << endl; // output the x after called swap
    cout << y << endl; // output the y after called swap
    
    return 0;
}
