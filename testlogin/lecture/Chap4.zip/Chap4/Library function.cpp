//
//  Library function.cpp
//

#include <iostream>
#include <cmath>
using namespace std;

int main(){
    
    int x = 100;  // define x
    int squareroot;
    
    squareroot = sqrt(x); // implement one of the cmath librabry functions
    cout << "Square root of 100 is" << squareroot << endl;
    
    return 0;
}
