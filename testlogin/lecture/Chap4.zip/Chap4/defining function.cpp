//
//  defining function.cpp
//  

#include <iostream>
using namespace std;

int min (int a, int b){
    
    if (a < b)
        return a; //return a as an integer which matches the return type
    else
        return b; //return b as an integer which matches the return type
}
