//
//  accessing elements in 2-d array.cpp
//  

#include <iostream>
using namespace std;

int main () {
    // an array with 4 rows and 2 columns.
    int my_array[4][2] = { {0,0}, {1,1}, {2,2}, {3,3}};
    
    // access the element in 2-D array by nested for loop
    for ( int x = 0; x < 5; x++ )
        for ( int y = 0; y < 2; y++ ) {
            cout << "my_array[" << x << "][" << y << "]: ";
            cout << my_array[x][y]<< endl;
        }
    
    return 0;
}
