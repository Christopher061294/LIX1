//
//  multi-dimensional array declaring.cpp
//  

#include <iostream>
using namespace std;

int main(){

    int my_array [3][4][5];
    
    return 0;
}
