//
//  Initializing array.cpp
//  

#include <iostream>
using namespace std;

int main() {
    
    int my_array[10] = {1,2,3,4,5,6,7,8,9,10};
    // initializing my_array with contents of 1 to 10
    
    
    int his_array[5] = {1,2,3};
    // if the initializing value is not enough, zero will be add to the remaining seat after filling up the front slots
    
    
    int her_array[] = {1,2,3,4};
    // if you didn't declare the size of the array when initializing, the compiler will automatically generate an array just big enough to hold the initialization created    
    
    return 0;
}
