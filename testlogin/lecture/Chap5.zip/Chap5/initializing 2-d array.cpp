//
//  initializing 2-d array.cpp
//  

#include <iostream>
using namespace std;

int main(){
    
    int my_array[3][4] = { // size of the 2-d array is 3*4
        {1, 1, 1, 1} ,   //  initialize row 0
        {2, 2, 2, 2} ,   //  initialize row 1
        {3, 3, 3, 3}     //  initialize row 2
    };
    
    return 0;
}
