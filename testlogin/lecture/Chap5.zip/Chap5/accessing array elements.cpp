//
//  accessing array elements.cpp
//  

#include <iostream>
using namespace std;



int main ()
{
    int my_array[] = {1, 2, 3, 4, 5}; // initialize array
    int n;                            //counter
    int result = 0;
    
    for ( n=0 ; n<5 ; ++n ) // use for loop to access the element
    {
        result = result + my_array[n];
    }
    cout << result;
    
    return 0;
}
