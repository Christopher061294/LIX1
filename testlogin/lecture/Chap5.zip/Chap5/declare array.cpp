//
//  declare array.cpp
//  


#include <iostream>
using namespace std;

int main() {
    
    int my_array [10]; // declare an array of int type with size 10
    
    return 0;
    
}
