//
//  if_statement.cpp
//  

#include <iostream>
using namespace std;

int main()
{
    int x = 1
    
    if (x == 1)
        cout << "x is" << x << endl;
    
    return 0;
}
