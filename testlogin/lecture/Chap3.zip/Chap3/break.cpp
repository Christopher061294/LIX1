//
//  break.cpp
//  
#include <iostream>
using namespace std;

int main ()
{
    
    int x = 0;
    
    do  // do-while loop
    {
        cout << "x is" << x << "now"<<endl;
        x++; // increment x after statement
        if( x > 3)
        {
            break;  // force termination of the loop
        }
    }while( x < 10 );
    
    return 0;
}
