//
//  switch_statement.cpp
//
#include <iostream>
using namespace std;

int main () {
    
    char grade = 'D';
    
    switch(grade) {
        case 'A' :                  //if the grade is 'A'
            cout << "You got an A" << endl;
            break;
        case 'B' :                  //if the grade is 'B' or 'c'
        case 'C' :
            cout << "You got a B/C" << endl;
            break;
        case 'D' :                  //if the grade is 'D'
            cout << "You got a D" << endl;
            break;
        case 'F' :                  //if the grade is 'F'
            cout << "sosad" << endl;
            break;
        default :                   //default case
            cout << "Invalid grade" << endl;
    }
    cout << "Your grade is " << grade << endl;
    
    return 0;
}
