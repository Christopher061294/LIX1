//
//  continue.cpp
//  
#include <iostream>
using namespace std;

int main ()
{
    int x = 0;
    do  //do-while loop
    {
        x++; // increment x first
        if(x > 3 && x < 5)
            continue; // continue when satisfying the two conditions above which is 4
        
        cout << "x is" << x << "now" <<endl;
    }while( x < 10 );
    
    return 0;
}
