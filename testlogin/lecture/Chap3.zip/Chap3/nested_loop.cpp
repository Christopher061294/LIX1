//
//  nested_loop.cpp
//  
#include <iostream>
using namespace std;

int main ()
{
    int x, y;
    
    for(x=0; x<=5; x++) { // first for statement
        
        for(y=0; y <= 5; y++) {  // second for statement
            cout << x << y <<" \t"; // execute inner statement
        }
        
        cout <<endl; // then follow by outter statement after inner loop is finished
    }
    
    return 0;
}
