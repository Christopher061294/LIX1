//
//  nested-if statement.cpp
//
#include <iostream>
using namespace std;

int main () {
    
    int x = 1;
    int y = 2;
    
    
    if( x == 1 ) { // check the condition 1
        
        cout << " x is 1" << endl; // execute statement 1
        
        // if condition 1 is true then check condition 2
        if( y == 2) {
            
            cout << "y is 2" << endl; // execute statement 2
        }
    }

    return 0;
}
