//
//  for_loop.cpp
//  
#include <iostream>
using namespace std;

int main () {
    // initialization of variable x, condition, after process
    for( int x = 1; x < 5; x++ ) {
        // execute statement as long as condition is true
        cout << "x is" << x << endl;
    }
    
    return 0;
}
