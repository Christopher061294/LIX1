//
//  if-else-if_statement.cpp
//  
#include <iostream>
using namespace std;

int main () {
    int x = 1;
    // check the boolean condition 1
    if( x == 0 ) {
        // if condition 1 is true
        cout << "Value of x is 0" << endl;
    } else if( x == 2 ) {
        // if else if condition 2 is true
        cout << "Value of x is 2" << endl;
    } else if( x == 3 ) {
        // if else if condition 3 is true
        cout << "Value of x is 3" << endl;
    }else {
        // if none of the conditions is true
        cout << "no value is matched with x" << endl;
    }
    cout << "Exact value of x is : " << x << endl;
    
    return 0;
}
