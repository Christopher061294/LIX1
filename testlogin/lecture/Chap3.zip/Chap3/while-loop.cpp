//
//  while-loop.cpp
//
#include <iostream>
using namespace std;

int main()
{
    
    int x = 1;
    
    while( x < 5 ) {  // test the condition
        // if true then execute statement
        cout << "x is " << x << endl;
        x++;
    }
    
    return 0;
}
