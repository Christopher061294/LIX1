//
//  if-else_statement.cpp
//
#include <iostream>
using namespace std;

int main()
{
    int x = 0;
    
    if (x == 1)
        cout << "x is" << x << endl;
    else
        cout << "x is not 1" << endl;

    return 0;
}
